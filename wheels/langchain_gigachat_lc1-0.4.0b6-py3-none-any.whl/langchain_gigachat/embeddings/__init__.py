from langchain_gigachat.embeddings.gigachat import GigaChatEmbeddings

__all__ = ["GigaChatEmbeddings"]
